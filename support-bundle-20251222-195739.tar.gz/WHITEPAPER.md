# Africoin: Continental Logistics Protocol
Details on the 1% Burn Flywheel and Sovereign Proof-of-Safety (PoS).
