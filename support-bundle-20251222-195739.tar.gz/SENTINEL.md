# Sentinel Operations Manual
Target Audience: 2,000+ Track Workers

## Proof of Safety (PoS)
Sentinels use the mobile portal to submit status reports.
1. **Login:** Via phone number (linked to Sui wallet).
2. **Scan:** QR code at track checkpoints.
3. **Report:** Submit status (Clear/Maintenance/Obstructed).
4. **Reward:** Instant AFRC payout upon consensus verification.
