# Contributing to Africa Railways
1. Fork the repo.
2. Create a feature branch: `git checkout -b feature/new-logic`.
3. Ensure all Go telemetry scripts execute from the root folder.
4. Submit a Pull Request for review by the 10 Core Tech Staff.
