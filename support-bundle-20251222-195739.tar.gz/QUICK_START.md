# ⚡ Quick Start Guide

## 🎯 TL;DR - Get Building in 5 Minutes

### 1. Set Up Secrets (One Time)

```bash
chmod +x setup-eas-secrets.sh && ./setup-eas-secrets.sh
```

Enter when prompted:
- Backend URL: `https://africa-railways.vercel.app`
- Railways API Key: Your secret key
- Africoin API Key: Your secret key

### 2. Build Apps

```bash
# Railways App
eas build --platform android --profile railways

# Africoin App
eas build --platform android --profile africoin
```

### 3. Done! 🎉

Download your APKs from the EAS dashboard.

---

## 📱 App Configuration

### Railways App
- **Name:** Africa Railways Hub
- **Bundle ID:** com.mpolobe.railways
- **Project ID:** 82efeb87-20c5-45b4-b945-65d4b9074c32
- **Backend:** https://africa-railways.vercel.app
- **API Key:** RAILWAYS_API_KEY (from EAS secrets)

### Africoin App
- **Name:** Africoin Wallet
- **Bundle ID:** com.mpolobe.africoin
- **Project ID:** 5fa2f2b4-5c9f-43bf-b1eb-20d90ae19185
- **Backend:** https://africa-railways.vercel.app (same backend!)
- **API Key:** AFRICOIN_API_KEY (from EAS secrets)

---

## 🔑 Required EAS Secrets

| Secret Name | Used By | Description |
|-------------|---------|-------------|
| `BACKEND_URL` | Both apps | Backend API URL |
| `RAILWAYS_API_KEY` | Railways | Authentication key |
| `AFRICOIN_API_KEY` | Africoin | Authentication key |

Set them with:
```bash
eas secret:create --scope project --name BACKEND_URL --value "https://africa-railways.vercel.app"
eas secret:create --scope project --name RAILWAYS_API_KEY --value "your-key"
eas secret:create --scope project --name AFRICOIN_API_KEY --value "your-key"
```

---

## 🚀 Common Commands

### Development
```bash
# Start dev server
npm start

# Start as specific app
APP_VARIANT=railways npm start
APP_VARIANT=africoin npm start
```

### Building
```bash
# Build Railways (production)
eas build --platform android --profile railways

# Build Africoin (production)
eas build --platform android --profile africoin

# Build locally (faster, for testing)
eas build --platform android --profile railways --local
```

### Secrets Management
```bash
# List all secrets
eas secret:list

# Update a secret
eas secret:create --scope project --name BACKEND_URL --value "new-url" --force

# Delete a secret
eas secret:delete --name SECRET_NAME
```

### Troubleshooting
```bash
# Clear build cache
eas build --platform android --profile railways --clear-cache

# View build logs
eas build:list
eas build:view [build-id]

# Check project configuration
eas project:info
```

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────┐
│   Single Backend (Vercel)           │
│   africa-railways.vercel.app        │
│                                     │
│   • Validates API keys              │
│   • Returns app-specific data       │
└─────────────────────────────────────┘
              ▲
              │
      ┌───────┴───────┐
      │               │
┌─────▼─────┐   ┌────▼──────┐
│ Railways  │   │ Africoin  │
│    App    │   │    App    │
│           │   │           │
│ Uses:     │   │ Uses:     │
│ RAILWAYS_ │   │ AFRICOIN_ │
│ API_KEY   │   │ API_KEY   │
└───────────┘   └───────────┘
```

**Key Points:**
- ✅ One backend serves both apps
- ✅ Apps authenticate with different API keys
- ✅ Backend detects which app is calling
- ✅ Same codebase, different branding

---

## 🔧 Configuration Files

### eas.json
```json
{
  "build": {
    "railways": {
      "env": {
        "APP_VARIANT": "railways",
        "BACKEND_URL": "$BACKEND_URL",
        "API_KEY": "$RAILWAYS_API_KEY"
      }
    },
    "africoin": {
      "env": {
        "APP_VARIANT": "africoin",
        "BACKEND_URL": "$BACKEND_URL",
        "API_KEY": "$AFRICOIN_API_KEY"
      }
    }
  }
}
```

### app.config.js
```javascript
const IS_RAILWAYS = process.env.APP_VARIANT === 'railways';

export default {
  expo: {
    name: IS_RAILWAYS ? "Africa Railways Hub" : "Africoin Wallet",
    slug: IS_RAILWAYS ? "africa-railways" : "africoin-app",
    extra: {
      backendUrl: process.env.BACKEND_URL,
      apiKey: process.env.API_KEY
    }
  }
};
```

---

## 🐛 Common Issues

### "API key not configured"
```bash
# Check secrets exist
eas secret:list

# Set if missing
eas secret:create --scope project --name RAILWAYS_API_KEY --value "your-key"
```

### "Cannot connect to backend"
```bash
# Verify backend URL
eas secret:list | grep BACKEND_URL

# Test backend is running
curl https://africa-railways.vercel.app/health
```

### "Build failed"
```bash
# Clear cache and rebuild
eas build --platform android --profile railways --clear-cache
```

### "Wrong app variant"
```bash
# Check APP_VARIANT in eas.json
# Verify you're using correct build profile
eas build --platform android --profile railways  # Not africoin!
```

---

## 📚 Full Documentation

- [SETUP_GUIDE.md](./SETUP_GUIDE.md) - Complete setup instructions
- [ARCHITECTURE.md](./ARCHITECTURE.md) - System architecture details
- [README.md](./README.md) - Project overview

---

## 🆘 Need Help?

1. Check [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed instructions
2. Review [Expo Documentation](https://docs.expo.dev/)
3. Check [EAS Build Docs](https://docs.expo.dev/build/introduction/)

---

## ✅ Checklist

Before building:
- [ ] EAS secrets configured (`eas secret:list`)
- [ ] Backend deployed and running
- [ ] API keys match between mobile and backend
- [ ] Correct build profile selected

Before submitting to Play Store:
- [ ] App tested on physical device
- [ ] Version number incremented
- [ ] Screenshots prepared
- [ ] Store listing ready
- [ ] Privacy policy updated

---

**Ready to build?** Run:
```bash
eas build --platform android --profile railways
```
